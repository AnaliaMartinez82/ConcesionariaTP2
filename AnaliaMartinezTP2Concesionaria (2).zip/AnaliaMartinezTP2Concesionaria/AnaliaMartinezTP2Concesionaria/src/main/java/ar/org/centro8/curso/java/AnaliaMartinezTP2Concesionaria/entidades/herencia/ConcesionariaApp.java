package ar.org.centro8.curso.java.AnaliaMartinezTP2Concesionaria.entidades.herencia;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ConcesionariaApp {

    static List<Vehiculo> vehiculos= new ArrayList<>();//Creo el ArrayList vehiculos de la clase Vehiculo
    public static void main(final String[] args) {
        // List<Vehiculo> vehiculos= new ArrayList<>();//Creo el ArrayList vehiculos de la clase Vehiculo
        vehiculos.add(new Auto("Peugeot","206",4,200000.00));
        vehiculos.add(new Moto("Honda","Titan",125,60000.00));
        vehiculos.add(new Auto("Peugeot","208",5,250000.00));
        vehiculos.add(new Moto("Yamaha","YBR",160,80500.00));

        vehiculos.forEach(System.out::println);
        vehiculoMasCaro();
        vehiculoMasBarato();
        modeloLetraY();
        precioDecresciente();
    }
    //--------------------final metodo Main--------------------------------------------------
        //Metodo para obtener el vehiculo más caro
       public static void vehiculoMasCaro(){
          vehiculos
                   .stream()
                   .filter(v->v.getPrecio()== (
                          vehiculos
                                   .stream()
                                  .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                                  .get()
                                  .getPrecio()
                   ))
                //    .forEach(System.out::println);
                    .forEach(v -> System.out.println("El vehículo más caro: " + v.getMarca() + " " + v.getModelo()));
               
       }    
       

        public static void vehiculoMasBarato(){
         double precioMinimo = vehiculos
                                       .stream()
                                       .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                                       .get()
                                       .getPrecio();
         vehiculos
                  .stream()
                  .filter(v->v.getPrecio()== precioMinimo)
                  .forEach(v -> System.out.println("El vehículo más barato: "+ v.getMarca() + " " + v.getModelo()));
        }
        
        public static void modeloLetraY(){
           vehiculos
                   .stream()
                   .filter(v->v.getModelo().contains("Y"))
                   .forEach(v-> System.out.println("Vehiculo que contiene en el modelo la letra 'Y': " + v.getMarca() +" "+ v.getModelo() +" $"+ v.getPrecio()));
        }

        public static void precioDecresciente(){
            System.out.println("Vehículos ordenados por precio de mayor a menor:");
            vehiculos
                    .stream()
                    .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                    .forEach(v-> System.out.println( v.getMarca() + " " +v.getModelo()));
        }

        // public static void ordenNatural(){
        //     System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
        //     // Collections.sort(vehiculos);
        //     // vehiculos.forEach(System.out::println);
        //     vehiculos
        //             .stream()
        //             .sorted(Comparator.comparing(Vehiculo::getMarca))
        //             .thenComparing(Vehiculo::getModelo)
        //             .thenComparingDouble(Vehiculo::getPrecio);
        //             .forEach(System.out::println);

        }
       
}
