package ar.org.centro8.curso.java.AnaliaMartinezTP2Concesionaria.entidades.herencia;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Auto extends Vehiculo {
   private int puerta;

   public Auto(String marca, String modelo, int puerta, Double precio){
      super(marca, modelo, precio);
      this.puerta=puerta;
   }


   @Override
    protected String obtenerMensajeAdicional() {
        return "Puertas: " + puerta + " //";
    }
}
