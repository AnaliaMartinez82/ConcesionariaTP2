package ar.org.centro8.curso.java.AnaliaMartinezTP2Concesionaria.entidades.herencia;


import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Comparator;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public abstract class Vehiculo implements Comparable<Vehiculo> {
   private String marca;
   private String modelo;
   private Double precio;

   @Override
   public String toString(){
     DecimalFormatSymbols simbolos = new DecimalFormatSymbols();
    simbolos.setDecimalSeparator(',');// para que use la coma como separador decimal.
    simbolos.setGroupingSeparator('.'); // para que use el punto como separador de miles.

    DecimalFormat formato = new DecimalFormat("#,##0.00", simbolos);// patrón para incluir separadores y siempre mostrar dos decimales.

    return   "Marca: " + marca + " //" +
                " Modelo: " + modelo + " //" +
                obtenerMensajeAdicional() +
                " precio: $" + formato.format(precio)+"\n";
   }

    protected String obtenerMensajeAdicional() {
        return "saldra otro valor";// Dependiendo quien lo llame se imprimira diferente valor
    }

   @Override
   public int compareTo(Vehiculo otro) {
      String thisVehiculo = this.getMarca() + this.getModelo() + this.getPrecio();
      String otroVehiculo = otro.getMarca() + otro.getModelo() + otro.getPrecio();
      return thisVehiculo.compareTo(otroVehiculo);
   }

   // @Override
   //  public int compareTo(Vehiculo otro) {
   //      int cmpMarca = this.getMarca().compareTo(otro.getMarca());
   //      if (cmpMarca != 0) return cmpMarca;

   //      int cmpModelo = this.getModelo().compareTo(otro.getModelo());
   //      if (cmpModelo != 0) return cmpModelo;

   //      return Double.compare(this.getPrecio(), otro.getPrecio());
   //  }
}
