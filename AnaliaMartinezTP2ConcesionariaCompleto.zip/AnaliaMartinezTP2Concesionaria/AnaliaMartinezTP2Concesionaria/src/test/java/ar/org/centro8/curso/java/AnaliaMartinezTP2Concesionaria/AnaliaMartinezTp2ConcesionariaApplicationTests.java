package ar.org.centro8.curso.java.AnaliaMartinezTP2Concesionaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnaliaMartinezTp2ConcesionariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
