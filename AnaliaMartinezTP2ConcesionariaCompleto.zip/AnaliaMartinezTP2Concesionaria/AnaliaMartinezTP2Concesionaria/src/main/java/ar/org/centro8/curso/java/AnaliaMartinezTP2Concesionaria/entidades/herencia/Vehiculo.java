package ar.org.centro8.curso.java.AnaliaMartinezTP2Concesionaria.entidades.herencia;

import java.text.DecimalFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public abstract class Vehiculo implements Comparable<Vehiculo> {
   private String marca;
   private String modelo;
   private Double precio;

   @Override
   public String toString() {
      DecimalFormat formato = new DecimalFormat("#,##0.00");// patrón para incluir separadores y siempre
                                                                      // mostrar dos decimales.
      return "Marca: " + marca + " //" +
            " Modelo: " + modelo + " //" +
            obtenerMensajeAdicional() +
            " precio: $" + formato.format(precio);
   }

   public String obtenerMensajeAdicional() {
      return "saldra otro valor";// Dependiendo quien lo llame se imprimira diferente valor
   }

   @Override
   public int compareTo(Vehiculo otro) {
      String thisVehiculo = this.getMarca() + this.getModelo() + this.getPrecio();
      String otroVehiculo = otro.getMarca() + otro.getModelo() + otro.getPrecio();
      return thisVehiculo.compareTo(otroVehiculo);
   }
}
