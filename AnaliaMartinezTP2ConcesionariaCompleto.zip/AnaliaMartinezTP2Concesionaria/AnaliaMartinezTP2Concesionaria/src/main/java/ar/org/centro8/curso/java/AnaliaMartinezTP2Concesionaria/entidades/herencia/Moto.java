package ar.org.centro8.curso.java.AnaliaMartinezTP2Concesionaria.entidades.herencia;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Moto extends Vehiculo {
   private int cilindrada;

   public Moto(String marca, String modelo, int cilindrada, Double precio){
      super(marca, modelo, precio);
      this.cilindrada=cilindrada;
   }

   @Override
    public String obtenerMensajeAdicional() {
        return "Cilindradas: " + cilindrada + "c //";
    }


}
