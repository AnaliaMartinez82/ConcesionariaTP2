package ar.org.centro8.curso.java.AnaliaMartinezTP2Concesionaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnaliaMartinezTp2ConcesionariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnaliaMartinezTp2ConcesionariaApplication.class, args);
	}

}
