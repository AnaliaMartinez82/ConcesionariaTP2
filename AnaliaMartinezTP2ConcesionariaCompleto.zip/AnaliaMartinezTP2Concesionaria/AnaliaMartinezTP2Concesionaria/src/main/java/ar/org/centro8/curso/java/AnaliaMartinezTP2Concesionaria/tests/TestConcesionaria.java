package ar.org.centro8.curso.java.AnaliaMartinezTP2Concesionaria.tests;

import ar.org.centro8.curso.java.AnaliaMartinezTP2Concesionaria.entidades.herencia.ConcesionariaApp;

public class TestConcesionaria {

    public static void main(String[] args) {
        // llama los metodos creados en la clase que contiene la logica requerida:
        // ConsecionariaApp
        System.out.println();
        ConcesionariaApp.crearListaVehiculo();
        ConcesionariaApp.separacionRequerida();
        ConcesionariaApp.vehiculoMasCaro();
        ConcesionariaApp.vehiculoMasBarato();
        ConcesionariaApp.modeloLetraY();
        ConcesionariaApp.separacionRequerida();
        ConcesionariaApp.precioDecresciente();
        ConcesionariaApp.separacionRequerida();
        ConcesionariaApp.ordenNatural();
    }
}
